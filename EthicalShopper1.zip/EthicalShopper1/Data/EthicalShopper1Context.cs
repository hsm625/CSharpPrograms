﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EthicalShopper1.Models;

namespace EthicalShopper1.Data
{
    public class EthicalShopper1Context : DbContext
    {
        public EthicalShopper1Context (DbContextOptions<EthicalShopper1Context> options)
            : base(options)
        {
        }

        public DbSet<EthicalShopper1.Models.Restaurant> Restaurant { get; set; }
    }
}
