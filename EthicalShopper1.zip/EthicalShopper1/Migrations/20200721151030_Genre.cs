﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EthicalShopper1.Migrations
{
    public partial class Genre : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Ethnicity",
                table: "Restaurant",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Genre",
                table: "Restaurant",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Ethnicity",
                table: "Restaurant");

            migrationBuilder.DropColumn(
                name: "Genre",
                table: "Restaurant");
        }
    }
}
