﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EthicalShopper1.Data;
using EthicalShopper1.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EthicalShopper1.Pages.Restaurants
{
    public class IndexModel : PageModel
    {
        private readonly EthicalShopper1.Data.EthicalShopper1Context _context;

        public IndexModel(EthicalShopper1.Data.EthicalShopper1Context context)
        {
            _context = context;
        }

        public IList<Restaurant> Restaurant { get;set; }
        [BindProperty(SupportsGet = true)]
        public string SearchString { get; set; } //holds the text the user enters in the search text box.
        //The following SelectLists require "using Microsoft.AspNetCore.Mvc.Rendering;"
        public SelectList Genres { get; set; }
        public SelectList Ethnicities { get; set; }
        [BindProperty(SupportsGet = true)]
        public string RestaurantGenre { get; set; } //contains the specific genre the user selects
        [BindProperty(SupportsGet = true)]
        public string RestaurantEthnicity { get; set; } //contains the restaurant ethnicity, for example "American" "Asian" "Mexican"

        public async Task OnGetAsync()
        {
            //Define the LINQ Query
            var restaurants = from r in _context.Restaurant select r;

            //If the search string isn't null or empty, modify the query to filter the search.
            if (!string.IsNullOrEmpty(SearchString))
            {
                restaurants = restaurants.Where(s => s.RestaurantName.Contains(SearchString));
            }

            //ToListAsync is what executes the query. Defining or modifying the query does not execute it.
            Restaurant = await restaurants.ToListAsync();
            //Restaurant = await _context.Restaurant.ToListAsync();
        }
    }
}
