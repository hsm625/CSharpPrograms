﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EthicalShopper1.Models
{
    public class Restaurant
    {
        public int ID { get; set; }
        public int RestaurantCode { get; set; }
        [Display(Name = "Restaurant Name")]
        public String RestaurantName { get; set; }
        public String Company { get; set; }
        public String Address { get; set; }
        public String Genre { get; set; }
        public String Ethnicity { get; set; }
        public int MenuCode { get; set; }
    }
}
