﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EthicalShopper1.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace EthicalShopper1.Models
{
    public static class SeedData
    {
        public static void Initialize (IServiceProvider serviceProvider)
        {
            using (var context = new EthicalShopper1Context(serviceProvider.GetRequiredService<DbContextOptions<EthicalShopper1Context>>()))
            {
                if (context.Restaurant.Any())
                {
                    return; //DB has already been seeded
                }

                context.Restaurant.AddRange(
                    new Restaurant
                    {
                        RestaurantCode = 00000,
                        RestaurantName = "Bob's Generic Bar",
                        Company = "Bob's Bars",
                        Address = "777 Lucky Lane",
                        Genre = "Bar and Grill",
                        Ethnicity = "American",
                        MenuCode = 00000
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
